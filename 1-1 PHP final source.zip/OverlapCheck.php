<?php
    $conn = mysqli_connect('localhost','root','1079821','smij');

    if(!$conn) {
        die("DB connection failed".mysqli_error());
    }

    $dbname = 'smij';

    $dbconn = mysqli_select_db($conn,$dbname);
    if(!$dbconn) {
        die("DB selection failed".mysqli_error());
    }

    $userId = $_GET['userId'];
    $query_search = "SELECT * FROM login WHERE id='$userId'";
    
    $result = mysqli_query($conn,$query_search);
    $row = mysqli_num_rows($result);

    
    echo $row;

    mysqli_close($conn);
?>