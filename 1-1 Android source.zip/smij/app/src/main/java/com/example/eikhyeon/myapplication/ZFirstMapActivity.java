package com.example.eikhyeon.myapplication;

import android.Manifest;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.StringTokenizer;

public class ZFirstMapActivity extends AppCompatActivity implements OnMapReadyCallback {

    public static Intent intent;
    public static String userId;
    public static String tempResult;
    public static String vib,latlng,colum;
    public static String llat[];
    public static String llng[];
    public static  double doubleLat[]={0,};
    public static  double doubleLng[]={0,};
    public static int intColum;
    public static String arr[];
    public static MarkerOptions markerOptions;
    public static TextView sub1,sub2,sub3,sub4;
    public static String hWeight,hHeight,aWeight,dBirth,tRes;
    long mNow;
    Date mDate;
    SimpleDateFormat mFormat = new SimpleDateFormat("yyyy-MM-dd");
    double humanHeight;
    double dogWeight;
    double minute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zfirst_map);

        FragmentManager fragmentManager = getFragmentManager();
        final MapFragment mapFragment = (MapFragment)fragmentManager.findFragmentById(R.id.firstMap);
        mapFragment.getMapAsync(this);

        intent = getIntent();
        userId = intent.getStringExtra("useridid");
        //Toast.makeText(getApplicationContext(), userId, Toast.LENGTH_SHORT).show();

        sub1= (TextView)findViewById(R.id.firstMapSubText1);
        sub2=(TextView)findViewById(R.id.firstMapSubText2);
        sub3=(TextView)findViewById(R.id.firstMapSubText3);
        sub4=(TextView)findViewById(R.id.firstMapSubText4);


        PermissionListener permissionListener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                //Toast.makeText(ZFirstMapActivity.this, "권한 허용", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onPermissionDenied(ArrayList<String> arrayList) {
                Toast.makeText(ZFirstMapActivity.this, "권한 거절", Toast.LENGTH_SHORT).show();
            }
        };
        new TedPermission(this)
                .setPermissionListener(permissionListener)
                .setRationaleMessage("맵 허용 권한이 필요합니다")
                .setDeniedMessage("거부하면 어플리케이션을 사용하지 못합니다")
                .setPermissions(Manifest.permission.ACCESS_FINE_LOCATION)
                .check();

        try {
            tRes = new weightANDheight().execute(userId).get();
            StringTokenizer tokenizer = new StringTokenizer(tRes,";");
            hWeight=tokenizer.nextToken();
            hHeight=tokenizer.nextToken();
            aWeight=tokenizer.nextToken();
            dBirth=tokenizer.nextToken();


        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapReady(final GoogleMap googleMap) {
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(37.3396415,126.73474959999998)));
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(15);
        googleMap.animateCamera(zoom);

        try {
            tempResult = new firstMap().execute(userId).get();

            StringTokenizer tokenizer3=new StringTokenizer(tempResult,"_");
            vib=tokenizer3.nextToken();
            colum=tokenizer3.nextToken();
            intColum = Integer.parseInt(colum);
            latlng=tokenizer3.nextToken();


            arr=latlng.split(";");
            llat=new String[intColum];
            llng=new String[intColum];
            doubleLat=new double[intColum];
            doubleLng=new double[intColum];
            for(int i =0; i<intColum; i++) {
                StringTokenizer stringTokenizer = new StringTokenizer(arr[i], "&"); //latlng를 &로 나누면 lat 랑 lng랑 분리
                llat[i] = stringTokenizer.nextToken();
                llng[i] = stringTokenizer.nextToken();
                doubleLat[i] = Double.parseDouble(llat[i]);
                doubleLng[i] = Double.parseDouble(llng[i]);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        for(int k=0; k<intColum; k++) {
            markerOptions=new MarkerOptions();
            markerOptions.position(new LatLng(doubleLat[k],doubleLng[k]));
            googleMap.addMarker(markerOptions);
        }


        LatLng a=new LatLng(doubleLat[0],doubleLng[0]);
        LatLng b=new LatLng(doubleLat[intColum/2],doubleLng[intColum/2]);
        LatLng c=new LatLng(doubleLat[intColum-1],doubleLng[intColum-1]);

        double dis = getDistance(a,b,c);
        String strdis = String.format("%.2f",dis);
        sub1.setText("이 길의 대략적인 거리 : "+strdis+"m");



        humanHeight = Double.parseDouble(hHeight);
        double ccal = getCal(dis,humanHeight);
        String aa =String.format("%.2f",ccal);
        sub2.setText("대략적인 칼로리 소모량 : "+aa+"kcal");

        dogWeight = Double.parseDouble(aWeight);
        int vibInt = Integer.parseInt(vib);
        minute = vibInt/2050.0;

        if(dogWeight>0.0 && dogWeight<=10.0) {
            String asd  = String.format("%.2f",minute*3.3);
            sub3.setText("대략적인 칼로리 소모량 : "+asd+"kcal");
        }
        else if(dogWeight>10 && dogWeight<=20) {
            String asdasd  = String.format("%.2f",minute*1.4);
            sub3.setText("대략적인 칼로리 소모량 : "+asdasd+"kcal");
        }
        else if(dogWeight >20) {
            String asdasdasd  = String.format("%.2f",minute*0.4);
            sub3.setText("대략적인 칼로리 소모량 : "+asdasdasd+"kcal");
        }

        long year =doDiffOfDate(dBirth,getTime())/365;
        long tempMonth = doDiffOfDate(dBirth,getTime())%365;
        long month=tempMonth/30;

        if(year>=1) {
            String asd = String.format("%.2f",dogWeight*1000*0.02);
            sub4.setText("추천 사료량 : "+asd+"g을\n"+"하루 1~2회로 나누어 주세요");
        }
        else if (month<3) {
            String asd = String.format("%.2f",dogWeight*1000*0.04);
            sub4.setText("추천 사료량 : "+asd+"g을\n"+"하루에 4~5회로 나누어 주세요");
        }
        else if(month<6) {
            String asd = String.format("%.2f",dogWeight*1000*0.03);
            sub4.setText("추천 사료량 : "+asd+"g을\n"+"하루에 3회로 나누어 주세요");
        }
        else if(month>=6 && year<1) {
            String asd = String.format("%.2f",dogWeight*1000*0.02);
            sub4.setText("추천 사료량 : "+asd+"g을\n"+"하루에 2회로 나누어 주세요");
        }
    }

    //현재 시간 구하기
    private String getTime(){
        mNow = System.currentTimeMillis();
        mDate = new Date(mNow);
        return mFormat.format(mDate);
    }

    //키와 거리를 받아 칼로리 계산
    public double getCal(double dis, double height) {

        double mileToCal = 3.7103 + 0.2678*height+ (0.0359*(height*60*0.0006213)*2)*height;
        double cal = dis*mileToCal*0.0006213;
        return cal;
    }


    //마커사이의 거리 계산
    public double getDistance(LatLng latLng1, LatLng latLng2, LatLng latLng3) {
        double distance1;
        double distance2;
        double res;

        Location location1= new Location("A");
        location1.setLatitude(latLng1.latitude);
        location1.setLongitude(latLng1.longitude);

        Location location2=  new Location("B");
        location2.setLatitude(latLng2.latitude);
        location2.setLongitude(latLng2.longitude);

        Location location3=new Location("C");
        location3.setLatitude(latLng3.latitude);
        location3.setLongitude(latLng3.longitude);

        distance1=location1.distanceTo(location2);
        distance2=location2.distanceTo(location3);

        res = distance1+distance2;
        return res;
    }

    public long doDiffOfDate(String start,String end){
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date beginDate = formatter.parse(start);
            Date endDate = formatter.parse(end);

            // 시간차이를 시간,분,초를 곱한 값으로 나누면 하루 단위가 나옴
            long diff = endDate.getTime() - beginDate.getTime();
            long diffDays = diff / (24 * 60 * 60 * 1000);

            return diffDays;
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return 3;
    }


    public static DefaultHttpClient getThreadSafeClient() {
        DefaultHttpClient client = new DefaultHttpClient();
        ClientConnectionManager mgr = client.getConnectionManager();
        HttpParams params = client.getParams();
        client = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
                mgr.getSchemeRegistry()), params);
        return client;
    }



    class firstMap extends AsyncTask<String, Void, String> {
        protected void onPreExecute() { }
        @Override
        protected String doInBackground(String... params) {
            try {
                String userId = params[0];

                String eikLink="http://smij.dothome.co.kr/ZFirstMap_controller.php?userId="+userId;
                String taeLink ="http://52.78.186.198/ZFirstMap_controller.php?userId="+userId;
                String link = "http://192.168.60.38/ci/index.php/ZFirstMap_controller?userId="+userId;

                URL url = new URL(eikLink);
                HttpClient client = getThreadSafeClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(eikLink));
                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuffer sb = new StringBuffer("");
                String line = "";
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }
                in.close();
                return sb.toString();
            } catch (Exception e) {
                Log.w("Exception = ", e.getMessage());
            }
            return null;
        }
        protected void onPostExecute(String result) {}
    }

    class weightANDheight extends AsyncTask<String, Void, String> {
        protected void onPreExecute() { }
        @Override
        protected String doInBackground(String... params) {
            try {
                String userId = params[0];


                String eikLink="http://smij.dothome.co.kr/WeightHeight_controller.php?userId="+userId;
                String taeLink ="http://52.78.186.198/WeightHeight_controller.php?userId="+userId;
                String link = "http://192.168.60.38/ci/index.php/WeightHeight_controller?userId="+userId;

                URL url = new URL(eikLink);
                HttpClient client = getThreadSafeClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(eikLink));
                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuffer sb = new StringBuffer("");
                String line = "";
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }
                in.close();
                return sb.toString();
            } catch (Exception e) {
                Log.w("Exception = ", e.getMessage());
            }
            return null;
        }
        protected void onPostExecute(String result) {}
    }



    /*
    private void firstMap(String userId) {
        class firstMapController extends AsyncTask<String, Void, String> {
            protected void onPreExecute() { }
            @Override
            protected String doInBackground(String... params) {
                try {
                    String userId = params[0];

                    String link = "http:///ci/index.php/ZFirstMap_controller?userId="+userId;
                    URL url = new URL(link);
                    HttpClient client = getThreadSafeClient();
                    HttpGet request = new HttpGet();
                    request.setURI(new URI(link));
                    HttpResponse response = client.execute(request);
                    BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                    StringBuffer sb = new StringBuffer("");
                    String line = "";
                    while ((line = in.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    in.close();
                    return sb.toString();
                } catch (Exception e) {
                    Log.w("Exception = ", e.getMessage());
                }
                return null;
            }
            protected void onPostExecute(String result) {
                StringTokenizer tokenizer1 = new StringTokenizer(result,"<");
                String real = tokenizer1.nextToken();
                String dummy = tokenizer1.nextToken();

                StringTokenizer tokenizer2 = new StringTokenizer(real,"^");
                String first=tokenizer2.nextToken();

                StringTokenizer tokenizer3=new StringTokenizer(first,"_");
                vib=tokenizer3.nextToken();
                colum=tokenizer3.nextToken();
                intColum = Integer.parseInt(colum);
                latlng=tokenizer3.nextToken();

                //Toast.makeText(getApplicationContext(),llat[0],Toast.LENGTH_SHORT).show();

                arr=latlng.split(";");
                llat=new String[intColum];
                llng=new String[intColum];
                doubleLat=new double[intColum];
                doubleLng=new double[intColum];
                for(int i =0; i<intColum; i++) {
                    StringTokenizer stringTokenizer = new StringTokenizer(arr[i], "&"); //latlng를 &로 나누면 lat 랑 lng랑 분리
                    llat[i] = stringTokenizer.nextToken();
                    llng[i] = stringTokenizer.nextToken();
                    doubleLat[i] = Double.parseDouble(llat[i]);
                    doubleLng[i] = Double.parseDouble(llng[i]);
                }


            }
        }
        firstMapController firstMapController =new firstMapController();
        firstMapController.execute(userId);
    }
    */


}

