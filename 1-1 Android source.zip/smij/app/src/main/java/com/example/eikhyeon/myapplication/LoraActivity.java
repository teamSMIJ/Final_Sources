package com.example.eikhyeon.myapplication;

import android.app.FragmentManager;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;

public class LoraActivity extends AppCompatActivity implements OnMapReadyCallback {
    Button loraButton;
    TextView loraTestView;
    String loraString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lora);

        FragmentManager fragmentManager = getFragmentManager();
        final MapFragment mapFragment = (MapFragment)fragmentManager.findFragmentById(R.id.loraMap);
        mapFragment.getMapAsync(this);

        loraButton=(Button)findViewById(R.id.loraBtn);
        loraTestView=(TextView)findViewById(R.id.loraTestView);


        loraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    loraString = new receiveLoraModuleData().execute().get();
                    Toast.makeText(getApplicationContext(),loraString,Toast.LENGTH_SHORT).show();
                    loraTestView.setText(loraString);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }

        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(37.3396415,126.73474959999998)));
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(15);
        googleMap.animateCamera(zoom);
    }








    class receiveLoraModuleData extends AsyncTask<String, Void, String> {
        protected void onPreExecute() {
        }
        @Override
        protected String doInBackground(String... params) {
            try {

                String eikLink="http://smij.dothome.co.kr/Ltest5.php";
                String taeLink ="http://52.78.186.198/ModuleDataDownload_controller.php";
                String link = "http://192.168.60.38/ci/index.php/ModuleDataDownload_controller";

                URL url = new URL(eikLink);
                HttpClient client = getThreadSafeClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(eikLink));
                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuffer sb = new StringBuffer("");
                String line = "";
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }
                in.close();
                return sb.toString();
            } catch (Exception e) {
                Log.w("Exception = ", e.getMessage());
            }
            return null;
        }
        protected void onPostExecute(String result) {
        }
    }


    public static DefaultHttpClient getThreadSafeClient()  {

        DefaultHttpClient client = new DefaultHttpClient();
        ClientConnectionManager mgr = client.getConnectionManager();
        HttpParams params = client.getParams();
        client = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
                mgr.getSchemeRegistry()), params);
        return client;
    }
}
