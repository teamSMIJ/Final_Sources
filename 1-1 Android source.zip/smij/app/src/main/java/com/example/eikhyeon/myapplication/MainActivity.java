package com.example.eikhyeon.myapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.dd.morphingbutton.MorphingButton;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity {
    private EditText userId;
    private EditText userPw;
    HttpResponse httpResponse;
    HttpClient httpClient;
    HttpPost httpPost;
    List<NameValuePair> nameValuePairs;
    ProgressDialog dialog=null;
    String id;
    String pw;
    private int morphCounter1=1;
    private int morphCounter2=1;
    ///////////임시용버튼
    //Button goLora;
    ///////////임시용버튼
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        final MorphingButton loginBtn = (MorphingButton)findViewById(R.id.loginBtn0);
        final MorphingButton signupBtn = (MorphingButton)findViewById(R.id.signupBtn0);
        userId = (EditText)findViewById(R.id.mainEditId);
        userPw = (EditText)findViewById(R.id.mainEditPw);
        id = userId.getText().toString();
        pw = userPw.getText().toString();

        ///////////////////////////////////////////////////////////////////임시용버튼
        /*
        goLora = (Button)findViewById(R.id.goLora);
        goLora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,LoraActivity.class);
                startActivity(intent);
            }
        });
        */
        ///////////////////////////////////////////////////////////////////임시용버튼



        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*
                Toast.makeText(getApplicationContext(),"로그인",Toast.LENGTH_SHORT).show();
                Intent intent0 = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent0);*/
                //dialog=ProgressDialog.show(MainActivity.this,"","확인하는중",true);
                /*
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        login2(userId.getText().toString(),userPw.getText().toString());
                    }
                }).start();
                */

                onMorphClicked1(loginBtn);
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        login2(userId.getText().toString(),userPw.getText().toString());
                    }},2000);
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMorphClicked2(signupBtn);

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent1 = new Intent(MainActivity.this, SignupActivity.class);
                        startActivity(intent1);
                    }},2000);
            }
        });


        morphToSquare1(loginBtn, 0);
        morphToSquare2(signupBtn, 0);
    }

    private void onMorphClicked1(final MorphingButton m) {
        if(morphCounter1==1){

            morphCounter1=0;
            morphToSuccess(m);

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    morphCounter1++;
                    morphToSquare1(m,integer(R.integer.mb_animation));
                }},1500);
        }
    }

    private void onMorphClicked2(final MorphingButton m) {
        if(morphCounter2==1){

            morphCounter2=0;
            morphToSignup(m);

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    morphCounter2++;
                    morphToSquare2(m,integer(R.integer.mb_animation));
                }},1500);


        }

    }

    private void morphToSquare1(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params square = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_corner_radius_2))
                .width(dimen(R.dimen.mb_width_100))
                .height(dimen(R.dimen.mb_height_40))
                .color(color(R.color.econg_loginDefault))
                .colorPressed(color(R.color.econg_loginClicked))
                .text(getString(R.string.econg_login));
        btnMorph.morph(square);
    }

    private void morphToSquare2(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params square = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_corner_radius_2))
                .width(dimen(R.dimen.mb_width_100))
                .height(dimen(R.dimen.mb_height_40))
                .color(color(R.color.econg_loginDefault))
                .colorPressed(color(R.color.econg_loginClicked))
                .text(getString(R.string.econg_signup));
        btnMorph.morph(square);
    }

    private void morphToSuccess(final MorphingButton btnMorph) {
        MorphingButton.Params circle = MorphingButton.Params.create()
                .duration(integer(R.integer.mb_animation))
                .cornerRadius(dimen(R.dimen.mb_height_56))
                .width(dimen(R.dimen.mb_height_56))
                .height(dimen(R.dimen.mb_height_56))
                .color(color(R.color.mb_green))
                .colorPressed(color(R.color.mb_green_dark))
                .icon(R.drawable.checker2);
        btnMorph.morph(circle);
    }

    private void morphToSignup(final MorphingButton btnMorph) {
        MorphingButton.Params circle = MorphingButton.Params.create()
                .duration(integer(R.integer.mb_animation))
                .cornerRadius(dimen(R.dimen.mb_height_56))
                .width(dimen(R.dimen.mb_height_56))
                .height(dimen(R.dimen.mb_height_56))
                .color(color(R.color.mb_green))
                .colorPressed(color(R.color.mb_green_dark))
                .icon(R.drawable.signup);
        btnMorph.morph(circle);
    }

    private void morphToFailure(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params circle = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_height_56))
                .width(dimen(R.dimen.mb_height_56))
                .height(dimen(R.dimen.mb_height_56))
                .color(color(R.color.mb_red))
                .colorPressed(color(R.color.mb_red_dark))
                .icon(R.drawable.canceler2);
        btnMorph.morph(circle);
    }

    /*
    void login1() {
        try {
            httpClient = getThreadSafeClient();
            Log.w("Exception :","1");
            //String url="http:///ci/index.php/Login_controller";
            httpPost = new HttpPost("http:///ci/index.php/Login_controller");
            Log.w("Exception :","2");
            nameValuePairs = new ArrayList<NameValuePair>(2);
            Log.w("Exception :","3");
            nameValuePairs.add(new BasicNameValuePair("userId", userId.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("userPw", userPw.getText().toString()));
            Log.w("id/pw확인 = ","id = "+userId.getText().toString()+"pw = "+userPw.getText().toString());
            Log.w("Exception :","4");
            httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            Log.w("Exception :","5");
            httpResponse = httpClient.execute(httpPost);
            Log.w("Exception :","6");
            ResponseHandler<String> responseHandler = new BasicResponseHandler();
            Log.w("Exception :","7");
            final String response=httpClient.execute(httpPost,responseHandler);
            Log.w("Exception :","8");
            System.out.println("Response : "+response);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tv.setText("Respnose from PHP"+httpResponse);
                    dialog.dismiss();

                }
            });
            if(response.equalsIgnoreCase("user found")) {
                startActivity(new Intent(MainActivity.this,LoginActivity.class));
                finish();
            } else {
                Log.w("Login = ","failed");
            }
        }
        //catch(ClientProtocolException e1) {
           // dialog.dismiss();
           // Log.e("Exception1=",e1.getMessage());
        //}
        catch (IOException e2) {
            dialog.dismiss();
            Log.e("Exception2=",e2.getMessage());
        }
    }
    */

    private void login2(String id,String pw) {
        class sendPost extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String id = params[0];
                String pw = params[1];
                httpClient = getThreadSafeClient();

                httpPost = new HttpPost("http://smij.dothome.co.kr/Login_controller.php");
                //httpPost = new HttpPost("http://52.78.186.198/Login_controller.php");

                BasicNameValuePair userId = new BasicNameValuePair("userId", id);
                BasicNameValuePair userPw = new BasicNameValuePair("userPw", pw);
                List<NameValuePair> nameValuePairList = new ArrayList<NameValuePair>();
                nameValuePairList.add(userId);
                nameValuePairList.add(userPw);
                try {
                    UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(nameValuePairList, "UTF-8");
                    httpPost.setEntity(urlEncodedFormEntity);
                    try {
                        httpResponse = httpClient.execute(httpPost);
                        InputStream inputStream = httpResponse.getEntity().getContent();
                        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                        StringBuilder stringBuilder = new StringBuilder();
                        String buffered = null;
                        while ((buffered = bufferedReader.readLine()) != null) {
                            stringBuilder.append(buffered);
                        }
                        Log.w("서버메시지=", stringBuilder.toString());
                        if(stringBuilder.toString().contains("TRUE")) {
                            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                            intent.putExtra("userId",id);
                            startActivity(intent);
                        } else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this,"로그인 실패",Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        return stringBuilder.toString();

                    } catch (ClientProtocolException e1) {
                        Log.v("TAG", "First Exception caz of HttpResponese :" + e1);
                        e1.printStackTrace();
                    } catch (IOException e2) {
                        Log.v("TAG", "Second Exception caz of HttpResponse :" + e2);
                        e2.printStackTrace();
                    }
                } catch (UnsupportedEncodingException e3) {
                    Log.v("TAG", "An Exception given because of UrlEncodedFormEntity argument :" + e3);
                    e3.printStackTrace();
                }
                return null;
            }
            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                //dialog.dismiss();
            }
        }
        sendPost sendPost=new sendPost();
        sendPost.execute(id, pw);
    }



    public static DefaultHttpClient getThreadSafeClient()  {

        DefaultHttpClient client = new DefaultHttpClient();
        ClientConnectionManager mgr = client.getConnectionManager();
        HttpParams params = client.getParams();
        client = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
                mgr.getSchemeRegistry()), params);
        return client;
    }
}
